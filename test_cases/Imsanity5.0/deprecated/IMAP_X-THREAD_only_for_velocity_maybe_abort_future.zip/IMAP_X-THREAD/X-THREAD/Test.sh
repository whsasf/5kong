#!/bin/bash

echo "########## msgsend=$msgsend" >>debug.log

if [ "$msgsend" -eq 6 ];then
    
    #running IMAP X-THREAD command 
    prints "All message deliievered successfully,will running X-THREAD" "pure_telnet_msgsend" "2"
		uid_x-thread_utf8_all 	$Sanityuser1	
		xthreadc=$(cat imap-xthread.tmp |grep "X-THREAD" |grep $Sanityuser1 |wc -l )
		echo "########## xthreadc=$xthreadc" >>debug.log
		if [ "$xthreadc" -eq 2 ];then
			prints "X-THREAD command running successfully" "X-THREAD" "2"
			Result=0
		else
		  prints "X-THREAD command running failed" "X-THREAD" "1"
			Result=1
		fi
		summary "IMAP:X-THREAD" $Result
else
    prints "Not all message deliievered successfully,please check manually" "pure_telnet_msgsend" "1"
    summary "IMAP:X-THREAD" 1
fi

