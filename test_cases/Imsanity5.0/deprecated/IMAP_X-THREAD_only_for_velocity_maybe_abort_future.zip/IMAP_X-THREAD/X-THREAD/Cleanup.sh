#!/bin/bash

#unset keys
set_config_keys "/*/imapserv/enableXTHREAD" "false" 1 	
set_config_keys "/*/mss/ConversationViewEnabled" "false" 1 

#delete test acocunt
account_delete_fn $Sanityuser1
account_delete_fn $Sanityuser2
account_delete_fn $Sanityuser3

