#!/bin/bash
> debug.log
> summary.log
#Result=1_by_fefault
Result=1
start_time_tc

#set keys    
set_config_keys "/*/common/enableXTHREAD" "true" 0 	
set_config_keys "/*/common/enableXFIRSTLINE" "true" 0 


#create 3 test accounts
Sanityuser1=test$(echo $RANDOM)
Sanityuser2=test$(echo $RANDOM)
Sanityuser3=test$(echo $RANDOM)

account_create_fn $Sanityuser1
imboxstats $Sanityuser1@${default_domain} &>accountexist.tmp
ec=$(grep -i "Unable to get mailbox" accountexist.tmp |wc -l)
if [ "$ec" -eq 1 ];then
	account_create_fn $Sanityuser1
fi
#immsgdelete $Sanityuser1@${default_domain} -all 


account_create_fn $Sanityuser2
imboxstats $Sanityuser2@${default_domain} &>accountexist.tmp
ec=$(grep -i "Unable to get mailbox" accountexist.tmp |wc -l)
if [ "$ec" -eq 1 ];then
	account_create_fn $Sanityuser2
fi
#immsgdelete $Sanityuser2@${default_domain} -all 

account_create_fn $Sanityuser3
imboxstats $Sanityuser3@${default_domain} &>accountexist.tmp
ec=$(grep -i "Unable to get mailbox" accountexist.tmp |wc -l)
if [ "$ec" -eq 1 ];then
	account_create_fn $Sanityuser3
fi
#immsgdelete $Sanityuser3@${default_domain} -all 


# deliever thread messages
#(1)prepare messages
		cp 1-testmessage2to1.txt    1-testmessage2to1-SMTP.tmp
		cp 2-testmessage1re2.txt    2-testmessage1re2-SMTP.tmp
		cp 3-testmessage2re1.txt    3-testmessage2re1-SMTP.tmp
		cp 4-testmessage1to3.txt    4-testmessage1to3-SMTP.tmp
		cp 5-testmessage3re1.txt    5-testmessage3re1-SMTP.tmp
		cp 6-testmessage1re3.txt    6-testmessage1re3-SMTP.tmp

    sed -i 's/xx1/'$Sanityuser1'/g'  *testmessage*-SMTP.tmp
		sed -i 's/xx2/'$Sanityuser2'/g'  *testmessage*-SMTP.tmp
		sed -i 's/xx3/'$Sanityuser3'/g'  *testmessage*-SMTP.tmp


#(2)deliever message, total 6
msgsend=0
#Msgdata=$(cat 1-testmessage2to1-SMTP.tmp)
pure_telnet_msgsend $Sanityuser2 $Sanityuser1 "1-testmessage2to1-SMTP.tmp"
let msgsend=msgsend+sentflag

#Msgdata=$(cat 2-testmessage1re2-SMTP.tmp)
pure_telnet_msgsend $Sanityuser1 $Sanityuser2 "2-testmessage1re2-SMTP.tmp"
let msgsend=msgsend+sentflag

#Msgdata=$(cat 3-testmessage2re1-SMTP.tmp)
pure_telnet_msgsend $Sanityuser2 $Sanityuser1 "3-testmessage2re1-SMTP.tmp"
let msgsend=msgsend+sentflag

#Msgdata=$(cat 4-testmessage1to3-SMTP.tmp)
pure_telnet_msgsend $Sanityuser1 $Sanityuser3 "4-testmessage1to3-SMTP.tmp"
let msgsend=msgsend+sentflag

#Msgdata=$(cat 5-testmessage3re1-SMTP.tmp)
pure_telnet_msgsend $Sanityuser3 $Sanityuser1 "5-testmessage3re1-SMTP.tmp"
let msgsend=msgsend+sentflag

#Msgdata=$(cat 6-testmessage1re3-SMTP.tmp)
pure_telnet_msgsend $Sanityuser1 $Sanityuser3 "6-testmessage1re3-SMTP.tmp"
let msgsend=msgsend+sentflag


