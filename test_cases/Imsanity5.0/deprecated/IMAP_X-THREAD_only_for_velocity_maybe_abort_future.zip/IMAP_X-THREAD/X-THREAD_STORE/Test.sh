#!/bin/bash

echo "########## msgsend=$msgsend" >>debug.log
if [ "$msgsend" -eq 6 ];then
    
    #running IMAP X-THREAD command 
    prints "All message deliievered successfully,will running X-THREAD" "pure_telnet_msgsend" "2"
    uid_x-thread_utf8_all $Sanityuser1
		xthreadc=$(cat imap-xthread.tmp |grep "X-THREAD" |grep $Sanityuser1 |wc -l )
		target=`grep "X-THREAD" imap-xthread.tmp |awk '{print $3}' |awk -F "("  '{print $2}'|head -2|tail -1`
		echo "########## xthreadc=$xthreadc" >>debug.log
		if [ "$xthreadc" -eq 2 ];then
			prints "X-THREAD command running successfully,will run X-THREAD_STORE command" "X-THREAD" "2"
			uid_x-thread_store_flags_Seen $Sanityuser1
			#then check 
			uid_x-thread_utf8_all $Sanityuser1
			
			newc=$(grep "X-THREAD" imap-xthread.tmp|awk '{print $6}'|head -2|tail -1)
			if [ $newc -eq 0 ];then
		  	 prints "X-THREAD_STORE running successfully" "X-THREAD_STORE" "2"
		  	 Result=0
		  else
		     prints "X-THREAD_STORE running failed,please check manually" "X-THREAD_STORE" "1"
		  	 Result=1
			fi
			
			summary "IMAP:X-THREAD_STORE" $Result
		else
		  prints "X-THREAD command running failed,please check manuall" "X-THREAD" "1"
		  summary "IMAP:X-THREAD_STORE" 1
		fi
else
    prints "Not all message deliievered successfully,please check manually" "pure_telnet_msgsend" "1"
    summary "IMAP:X-THREAD_STORE" 1
fi


