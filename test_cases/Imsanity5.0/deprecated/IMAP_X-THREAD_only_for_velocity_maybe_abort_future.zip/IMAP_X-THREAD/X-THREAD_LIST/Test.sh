#!/bin/bash

echo "########## msgsend=$msgsend" >>debug.log
if [ "$msgsend" -eq 6 ];then
    
    #running IMAP X-THREAD command 
    prints "All message deliievered successfully,will running X-THREAD" "pure_telnet_msgsend" "2"
    uid_x-thread_utf8_all $Sanityuser1
		xthreadc=$(cat imap-xthread.tmp |grep "X-THREAD" |grep $Sanityuser1 |wc -l )
		echo "########## xthreadc=$xthreadc" >>debug.log
		if [ "$xthreadc" -eq 2 ];then
			prints "X-THREAD command running successfully,will run X-THREAD_LIST command" "X-THREAD" "2"
			target=$(grep "X-THREAD" imap-xthread.tmp |awk '{print $3}' |awk -F "("  '{print $2}'|head -2|tail -1)
      latuid=$(grep "X-THREAD" imap-xthread.tmp |awk '{print $4}' |head -2|tail -1)
      let tem=latuid-1
      echo "########## latuid=$latuid" >>debug.log
			echo "########## target=$target" >>debug.log
			echo "########## tem=$tem" >>debug.log
			
			#running X-THREAD_LIST
			
			uid_x-thread_list_utf8_all  $Sanityuser1
			uid1=$(grep "X-THREAD" imap-xthread_list.tmp |head -1|awk '{print $3}'|awk -F "(" '{print $2}')
			uid1=$(echo $uid1 | tr -d " ")
			uid2=$(grep "X-THREAD" imap-xthread_list.tmp |head -1|awk '{print $4}'|awk -F ")" '{print $1}')
			uid2=$(echo $uid2 | tr -d " ")
			echo "########## uid1=$uid1" >>debug.log
			echo "########## uid2=$uid2" >>debug.log
			
			if [[ $uid1 == $latuid  && $uid2 == $tem ]];then
				 prints "X-THREAD_LIST command running successfully" "X-THREAD_LIST" "2"
				 Result=0
			else
			   prints "X-THREAD_LIST command running failed" "X-THREAD_LIST" "1"
			   Result=1
			fi
			
			summary "IMAP:X-THREAD_LIST" $Result
		else
		  prints "X-THREAD command running failed,please check manuall" "X-THREAD" "1"
		  summary "IMAP:X-THREAD_LIST" 1
		fi
else
    prints "Not all message deliievered successfully,please check manually" "pure_telnet_msgsend" "1"
    summary "IMAP:X-THREAD_LIST" 1
fi


