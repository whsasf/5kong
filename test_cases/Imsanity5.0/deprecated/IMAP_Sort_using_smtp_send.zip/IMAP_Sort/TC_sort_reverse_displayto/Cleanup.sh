#!/bin/bash
#delete test acocunt
account_delete_fn $Sanityuser

