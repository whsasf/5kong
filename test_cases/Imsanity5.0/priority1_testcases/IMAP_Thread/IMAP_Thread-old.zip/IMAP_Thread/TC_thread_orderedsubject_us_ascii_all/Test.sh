#!/bin/bash
echo -e "\033[35m===== Testing ...\033[0m"
echo -e "\033[35m===== Testing ...\033[0m" >>debug.log
echo ${result[@]} | grep -q 1
if [ $? -ne 0 ];then
    imap_thread "test7" "INBOX" "ORDEREDSUBJECT US-ASCII" "all"
    verify_imapthread=$(cat imapthread.txt | grep -i "THREAD" | grep '(1 4) (2 3 5)' | wc -l)
    verify_imapthread=`echo $verify_imapthread | tr -d " "`
    echo "verify_imapthread=$verify_imapthread"  >>debug.log
    if [ "$verify_imapthread" == "1" ]
    then
        prints "IMAP THREAD for test7 is successful" "TC_thread_orderedsubject_us_ascii_all" "2"
        Result="0"
    else
        prints "-ERR IMAP THREAD for test7 is unsuccessful" "TC_thread_orderedsubject_us_ascii_all" "1"
        Result="1"
    fi
else
    prints "-ERR mail delivered unsuccessfully" "mail_send_thread" "1"
    Result="1"
fi
summary "IMAP:TC_thread_orderedsubject_us_ascii_all" $Result