#!/bin/bash
> debug.log
> summary.log
#Result=1_by_fefault
Result=1
start_time_tc  TC_thread_orderedsubject_us_ascii_all_tc
printtestsuit
echo -e "\033[35m===== Setting Up ...\033[0m"
echo -e "\033[35m===== Setting Up ...\033[0m" >>debug.log


#create test account
account_create_fn test7
immsgdelete test7@openwave.com -all 

#thread message deliever

mail_send_thread test7 "ORDEREDSUBJECT" "INBOX"
mail1=$Result
echo "mail1=$mail1"  >>debug.log
mail_send_thread test7 "ORDEREDSUBJECT" "INBOX"
mail2=$Result
echo "mail2=$mail2"  >>debug.log
mail_send_thread test7 "ORDEREDSUBJECT" "INBOX" 2
mail3=$Result
echo "mail3=$mail3" >>debug.log
mail_send_thread test7 "ORDEREDSUBJECT" "INBOX" 1
mail4=$Result
echo "mail4=$mail4" >>debug.log
mail_send_thread test7 "ORDEREDSUBJECT" "INBOX" 2
mail5=$Result
echo "mail5=$mail5" >>debug.log
result=($mail1 $mail2 $mail3 $mail4 $mail5)

