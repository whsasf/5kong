#!/bin/bash
echo -e "\033[35m===== Cleaning Up ...\033[0m"
echo -e "\033[35m===== Cleaning Up ...\033[0m" >>debug.log
#delete test acocunt
account_delete_fn test7
rm log_imfolderlist.txt
rm imapthread.txt
rm log_account_create.txt
rm log_account_delete.txt

cat debug.log   >> $debuglog
cat summary.log >> $summarylog
