#!/bin/bash
echo -e "\033[35m===== Cleaning Up ...\033[0m"
echo -e "\033[35m===== Cleaning Up ...\033[0m" >>debug.log
echo -e "\033[35m\n................running clran up for testsuits................\033[0m\n"
echo -e "\033[35m===== Cleaning Up ...\033[0m" >>debug.log
#unset these keys:
set_config_keys "/*/imapserv/enableTHREAD" "false" 1 	
set_config_keys "/*/mss/ConversationViewEnabled" "false" 1 
keytmp=$(cat keytemp)
#set_config_keys "/*/mss/currentIndexesVersion" "$keytmp"  1
rm keytemp