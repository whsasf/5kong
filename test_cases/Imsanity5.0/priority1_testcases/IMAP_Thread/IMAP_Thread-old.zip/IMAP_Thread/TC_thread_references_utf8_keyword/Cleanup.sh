#!/bin/bash
echo -e "\033[35m===== Cleaning Up ...\033[0m"
echo -e "\033[35m===== Cleaning Up ...\033[0m" >>debug.log
#delete test acocunt
account_delete_fn test3
rm imapfetch.txt
rm imapthread.txt
rm imapstore.txt
rm log_account_create.txt
rm log_account_delete.txt

cat debug.log   >> $debuglog
cat summary.log >> $summarylog
