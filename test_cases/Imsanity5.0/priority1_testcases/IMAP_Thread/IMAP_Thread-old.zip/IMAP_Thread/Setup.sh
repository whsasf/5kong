#!/bin/bash
#set these keys:
set_config_keys "/*/imapserv/enableTHREAD" "true" 1 	
set_config_keys "/*/mss/ConversationViewEnabled" "true" 1 	

#get values of  key:/*/mss/currentIndexesVersion
keytmp=$(imconfget -fullpath "/*/mss/currentIndexesVersion")
echo $keytmp >keytemp
sed  -i 's/ CF/\\nCF/g' keytemp 
#set_config_keys "/*/mss/currentIndexesVersion" 'CF_TimeIndex 0\nCF_SubjectIndex 0\nCF_FromIndex 0\nCF_SizeIndex 0\nCF_PriorityIndex 0\nCF_AttIndex 0\nCF_ToIndex 0\nCF_CcIndex 0\nCF_RMFlagIndex 0\nCF_UIDIndex 0\nCF_RecentIndex 0\nCF_ConversationIndex 0\nCF_ConversationIndex1 1\nCF_MessageFlagsIndex 1' 1