#!/bin/bash
printtestsuit 1